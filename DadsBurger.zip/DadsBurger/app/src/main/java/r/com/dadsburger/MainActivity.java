/************************************************************************
 *                                                                      *
 *  CSCI 322/522               Assignment 5                  Fall 2020  *
 *                                                                      *
 *     Class Name: MainActivity.java                                    *
 *                                                                      *
 *   Developer(s): Ariz Ansari ( Z1995929)                              *
 *                 Mohammed Mansoor Sharreef (Z1874994)                 *
 *       Due Date: 10 Oct 2020                                          *
 *                                                                      *
 *        Purpose: RadioButtons and RadioGroups.The application will    *
 *        count calories for custom burgers. As various selections are  *
 *        made for the burger, the calorie count will be directly       *
 *        computed and displayed                                        *
 ************************************************************************/

package r.com.dadsburger;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {                       // Main Activity.

    private Burger burger = new Burger();                                   //Class object.

    // Initialize the user interface
    @Override
    protected void onCreate(Bundle savedInstanceState) {                    //Creating instance.
        super.onCreate(savedInstanceState);                                 //Super Call.
        setContentView(R.layout.activity_main);                             //Main activity.

        // Add click listeners to the radio groups
        RadioGroup pattiesGroup = findViewById(R.id.pattiesGroup);          //Radio Group variable.
        RadioGroup cheeseGroup = findViewById(R.id.cheeseGroup);            //Radio Group variable.

        RadioGroupOnCheckedChangeListener radioGroupListener = new RadioGroupOnCheckedChangeListener(); // Radion Variable.
        pattiesGroup.setOnCheckedChangeListener(radioGroupListener);        //On Set check for radio groups.
        cheeseGroup.setOnCheckedChangeListener(radioGroupListener);         //On Set check for radio groups.

        // Add check change listener for the bacon
        CheckBox baconCheckBox = findViewById(R.id.baconCheckBox);          //Check Box varibale.
        baconCheckBox.setOnClickListener(new View.OnClickListener() {       //On Set check for checkbox.
            @Override
            public void onClick(View view) {                                //On click.
                burger.setBacon(baconCheckBox.isChecked());                 //Is checked method.
                updateCalories();                                           //Update Method.
            }
        });

        // Add event to the sauce seek bar
        SeekBar sauceSeekBar = findViewById(R.id.sauceSeekBar);             //Seekbar instance.
        sauceSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {//Seekbar listener.
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) { //On change seekbar.
                burger.setSauce(sauceSeekBar.getProgress());                //Change set on seekbar.
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Deliberately empty
            }

            // Display the final calories
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                updateCalories();
            }// Updating calories on set update calories.
        });
    }

    // Update the display of calories
    private void updateCalories() {                                         //update Calories Method
        TextView caloriesLabel = findViewById(R.id.caloriesLabel);          //Text view variable.
        caloriesLabel.setText("Calories: " + burger.getCalories());         //Set Text.
    }


    private class RadioGroupOnCheckedChangeListener implements RadioGroup.OnCheckedChangeListener {// Listen for check changes from patty and cheese groups

        // Handle the re-calculation of calories based on selected patties and/or cheese
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int id) {       //On checked radio group.
            switch(id) {                                                    //Switch Case id.
                case R.id.beefPattyButton:                                  //Case of beef patty.
                    burger.setPatty(Burger.BEEF_PATTY);                     //Set patty for beef.
                    break;                                                  //Break statement.

                case R.id.turkeyPattyButton:                                //Case of turkey patty.
                    burger.setPatty(Burger.TURKEY_PATTY);                   //Set patty for turkey.
                    break;                                                  //Break statement.

                case R.id.veggiePattyButton:                                //Case of veggie patty.
                    burger.setPatty(Burger.VEGGIE_PATTY);                   //Set patty for veggie.
                    break;                                                  //Break statement.

                case R.id.noCheeseButton:                                   //Case of no cheese.
                    burger.setCheese(Burger.NO_CHEESE);                     //Set patty no cheese.
                    break;                                                  //Break statement.

                case R.id.cheddarButton:                                    //Case of cheddar cheese.
                    burger.setCheese(Burger.CHEDDAR_CHEESE);                //Set patty cheddar cheese.
                    break;                                                  //Break statement.

                case R.id.mozzButton:                                       //Case of mozellera cheese.
                    burger.setCheese((Burger.MOZZ_CHEESE));                 //Set patty for mozellera cheese.
                    break;                                                  //Break statement.
            }

            // Update the calories display
            updateCalories();                                               //Update Calories method.
        }
    }
}