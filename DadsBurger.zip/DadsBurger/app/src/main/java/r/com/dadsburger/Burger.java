/************************************************************************
 *                                                                      *
 *  CSCI 322/522               Assignment 5                  Fall 2020  *
 *                                                                      *
 *     Class Name: Burger.java                                          *
 *                                                                      *
 *   Developer(s): Ariz Ansari ( Z1995929)                              *
 *                 Mohammed Mansoor Sharreef (Z1874994)                 *
 *       Due Date: 10 Oct 2020                                          *
 *                                                                      *
 *        Purpose: RadioButtons and RadioGroups.The application will    *
 *        count calories for custom burgers. As various selections are  *
 *        made for the burger, the calorie count will be directly       *
 *        computed and displayed                                        *
 ************************************************************************/
package r.com.dadsburger;

public class Burger {                                       //Public Class burger.
    private final int BEEF_PATTY_CALORIES = 50;             // Variable for Beef patty.
    private final int TURKEY_PATTY_CALORIES = 25;           // Variable for Turkey patty.
    private final int VEGGIE_PATTY_CALORIES = 10;           // Variable for Veggie patty.
    private final int BACON_CALORIES = 30;                  // Variable for Bacon.
    private final int CHEDDAR_CALORIES = 10;                // Variable for Cheddar cheese.
    private final int MOZZ_CALORIES = 15;                   // Variable for Mozzerella cheese.
    private final int ONE_FOURTH_SAUCE_CALORIES = 2;        // Variable for 1/4th serving of sauce.
    private final int ONE_HALF_SAUCE_CALORIES = 5;          // Variable for 1/2 serving of sauce.
    private final int THREE_FOURTHS_SAUCE_CALORIES = 7;     // Variable for 3/4th serving of sauce.
    private final int ONE_WHOLE_SAUCE_CALORIES = 10;        // Variable for 1  serving of sauce.

    public static final int BEEF_PATTY = 1;                 // Static values for Beef patty.
    public static final int TURKEY_PATTY = 2;               // Static values for Turkey patty.
    public static final int VEGGIE_PATTY = 3;               // Static values for Veggie patty.

    public static final int NO_CHEESE = 0;                  // Static values for no cheese.
    public static final int CHEDDAR_CHEESE = 1;             // Static values for cheddar.
    public static final int MOZZ_CHEESE = 2;                // Static values for mozerella.

    private int patty;
    private int cheese;
    private boolean bacon;
    private int sauce;

    // Set the sauce level
    public void setSauce(int sauce) {
        this.sauce = sauce;
    }   //Setter.

    // Set bacon
    public void setBacon(boolean bacon) {
        this.bacon = bacon;
    }//Setter.

    // Set the cheese
    public void setCheese(int cheese) {
        this.cheese = cheese;
    }//Setter.

    // Set the patty
    public void setPatty(int patty) {
        this.patty = patty;
    }   //Setter.

    // Calculate and return the total calories
    public int getCalories() {                              //Get calories Method.
        int calories = 0;                                   //Calories variable.

        // Add calories from patty
        switch(patty) {                                     //Switch case.
            case BEEF_PATTY:                                //Beef patty case.
                calories += BEEF_PATTY_CALORIES;            //Adding values.
                break;                                      //Break.
            case TURKEY_PATTY:                              //Case Turkey Patty.
                calories += TURKEY_PATTY_CALORIES;          //Adding values.
                break;                                      //Break.
            case VEGGIE_PATTY:                              //Case Veggie patty.
                calories += VEGGIE_PATTY_CALORIES;          //Adding values.
                break;                                      //Break.
        }

        // Add calories from bacon
        if(bacon)                                           //If for bacon.
            calories += BACON_CALORIES;                     //Adding values.

        // Add calories from cheese
        switch(cheese) {                                    //Switch.
            case CHEDDAR_CHEESE:                            //Case Cheddar.
                calories += CHEDDAR_CALORIES;               //Adding values.
                break;                                      //Break.
            case MOZZ_CHEESE:                               //Case Mozzeralla.
                calories += MOZZ_CALORIES;                  //Adding values.
                break;                                      //Break.
        }

        // Add calories from sauce
        if(sauce >= 100)                                    //if Condition for values addition.
            calories += ONE_WHOLE_SAUCE_CALORIES;           //Adding calories.
        else if(sauce >= 75)                                //Else if.
            calories += THREE_FOURTHS_SAUCE_CALORIES;       //Adding calories.
        else if(sauce >= 50)                                //Else if.
            calories += ONE_HALF_SAUCE_CALORIES;            //Adding calories.
        else if(sauce >= 25)                                //Else if.
            calories += ONE_FOURTH_SAUCE_CALORIES;          //Adding calories.

        return calories;                                    //Return Calories.
    }
}
