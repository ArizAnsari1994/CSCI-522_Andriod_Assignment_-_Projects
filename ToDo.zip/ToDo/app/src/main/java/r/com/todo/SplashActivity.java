package r.com.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

public class SplashActivity extends AppCompatActivity {                         // Splash Activity class.

    // Start the splash screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {                        // On create override.
        super.onCreate(savedInstanceState);                                     // Create Instance.
        setContentView(R.layout.activity_splash);                               // Display activity splash.

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,        // setFlag display for the splash screen.
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();                                           // Hide method for action bar.

        // Wait for 3 seconds before showing the main activity
        new Handler().postDelayed(new Runnable() {                              // handler class to delay the display screen.
            @Override
            public void run() {                                                 //Override run method.
                Intent intent =new Intent(SplashActivity.this, MainActivity.class);// intent object for the main activity class.
                startActivity(intent);                                          // Starting intent
                finish();                                                       // Finish.
            }
        }, 3000);                                                     //Delay.
    }
}