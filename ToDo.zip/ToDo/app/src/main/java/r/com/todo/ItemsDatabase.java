package r.com.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

public class ItemsDatabase  {                                           // Item database class.

    private SQLiteDatabase database;                                    // Sql databse variable.


    // Initialize the items database
    public ItemsDatabase(Context context) {                             // Items Database.
        DatabaseHelper dbHelper = new DatabaseHelper(context);          // Data base helper for context.
        database = dbHelper.getWritableDatabase();                      // database get writable.
    }

    // Insert a new item into the table
    public void insertItem(Item item) {                                 // Insert Item method.
        ContentValues values = new ContentValues();                     // content values.
        values.put("task", item.task);                                  // Put values.
        values.put("completed", item.completed ? "true" : "false");     // Put values.
        database.insert("items", "", values);       // Insert into database.
    }

    // Update the details of an item
    public void updateItem(Item item) {                                 // Update Item method.
        ContentValues values = new ContentValues();                     // content values variable.
        values.put("task", item.task);                                  // put value.
        values.put("completed", item.completed ? "true" : "false");     // put value.
        database.update("items", values, "_id=?", new String[]{ String.valueOf(item.id) });// database update.
    }

    // Return all items
    public Cursor retrieveItems() {                                     // cursor method.
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();     // sql lite builder.
        queryBuilder.setTables("items");                                // Set table items.

        return queryBuilder.query(                                      // Return query for insertions.
                database,
                new String[]{ "_id", "task", "completed" },
                null,
                null,
                null,
                null,
                "_id");
    }

    // Delete an item given an id
    public void deleteItem(int id) {                                     // Delete items method.
        database.delete("items", "_id=?", new String[]{ String.valueOf(id) });// Items delete form database.
    }

    // Delete all items
    public void deleteAll() {
        database.delete("items", null, null);
    }// Delete all.

    // Helper for database management
    private class DatabaseHelper extends SQLiteOpenHelper {             // Database Helper.
        public static final int DB_VERSION = 1;                         // static variable.
        public static final String DB_NAME = "ItemsDb";                 // static string variabl.

        // Initialize the database connection
        public DatabaseHelper(Context context) {                        // Database Helper context variable.
            super(context, DB_NAME, null, DB_VERSION);          // Super class call.
        }

        // Create the database
        @Override
        public void onCreate(SQLiteDatabase db) {                       // On create sql database method.
            db.execSQL("create table items (" +                         // Exec sql database.
                    "_id integer primary key autoincrement, " +         // values.
                    "task varchar(100) not null," +
                    "completed varchar(10) not null)");
        }

        // Drop the table if there's a new version
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {// On updragde method.
            if(oldVersion == newVersion)                                // Old version if condition.
                return;                                                 // Return.

            db.execSQL("drop table items");                             // Exec sql drop item.
        }
    }
}
