package r.com.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class AddItemActivity extends AppCompatActivity {                            // Add Items activity.

    private ItemsDatabase database;                                                 // Database variable.

    // Initialize anything we need to initialize
    @Override
    protected void onCreate(Bundle savedInstanceState) {                            // Oncreate method.
        super.onCreate(savedInstanceState);                                         // super method.
        setContentView(R.layout.activity_add_item);                                 // layout method.

        database = new ItemsDatabase(this);                                 // New database object.
        displayItems(); // display items.
    }

    // Display the items on a list view
    private void displayItems() {                                                  // Display items.
        Cursor cursor = database.retrieveItems();                                  // Cursor object.
        ItemsCursorAdapter cursorAdapter = new ItemsCursorAdapter(this, cursor, 0);// Cursor adapter object.
        ((ListView)findViewById(R.id.listview_items)).setAdapter(cursorAdapter);    // R.id for list items.
    }

    // Add a new item to the database
    public void addItem(View view) {                                               // Add items method.
        EditText editTextTask = findViewById(R.id.edittext_task);                  // Edit text for R.id.
        String task = editTextTask.getText().toString().trim();                     // Task to string.

        if(task.isEmpty())                                                          // Task.is empty.
            return;                                                                 // Return .

        Item item = new Item();                                                     // Item variable.
        item.task = task;                                                           // Value assigning.
        item.completed = false;                                                     // boolean false.

        database.insertItem(item);                                                  // Database insert item variable.
        displayItems();                                                             // Display items method.

        editTextTask.setText("");                                                   // Set text
    }

    // End the activity
    public void back(View view) {                                                   // Back method.
        finish();                                                                   // Finish.
    }

    private class ItemsCursorAdapter extends CursorAdapter {                        // Items cursor adapter.
        private LayoutInflater layoutInflater;                                      // private layout.

        // Cursor for each item
        public ItemsCursorAdapter(Context context, Cursor cursor, int flags) {       // Items cursor adapter.
            super(context, cursor, flags);                                          // Super method.
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE); // layout variable.
        }

        // Display the item to the view
        @Override
        public void bindView(View view, Context context, Cursor cursor) {           // bind view method.
            String task = cursor.getString(cursor.getColumnIndex("task"));      // String task output.
            ((TextView)view.findViewById(R.id.textview_task)).setText(task);        // text view by id.
        }

        // Set the layout to be used for the display of each item
        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {     // new view method.
            return layoutInflater.inflate(R.layout.listview_row_item_text, parent, false);// Return layput.
        }
    }
}