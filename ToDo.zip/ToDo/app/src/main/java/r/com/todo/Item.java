package r.com.todo;

import java.io.Serializable;

public class Item implements Serializable {                             // Item class.
    public int id;                                                      // Public data member id.
    public String task;                                                 // Public data member id.
    public boolean completed;                                           // Public data member completed.
}
