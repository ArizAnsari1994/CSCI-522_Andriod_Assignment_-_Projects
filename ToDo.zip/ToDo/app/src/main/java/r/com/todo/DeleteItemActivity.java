package r.com.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

public class DeleteItemActivity extends AppCompatActivity {                         // Delete Items activity.

    private ItemsDatabase database;                                                 // Database variable.

    // Initialize the items
    @Override
    protected void onCreate(Bundle savedInstanceState) {                            // On create method.
        super.onCreate(savedInstanceState);                                         // Starting instance.
        setContentView(R.layout.activity_delete_item);                              // layout activity.

        database = new ItemsDatabase(this);                                 // Item database object.
        displayItems();                                                             // Display items method.
    }

    // Go back to main activity
    public void back(View view) {                                                   // View putout.
        finish();                                                                  // Finish activity.
    }

    // Display the items on a list view
    private void displayItems() {                                                   // Display items.
        Cursor cursor = database.retrieveItems();                                   // Cursor database.
        ItemsCursorAdapter cursorAdapter = new ItemsCursorAdapter(this, cursor, 0);// cursor adapter database.
        ((ListView)findViewById(R.id.listview_items)).setAdapter(cursorAdapter);    // R.id for display.
    }

    // Delete all items
    public void deleteAll(View view) {                                              // Delete method.
        database.deleteAll();                                                       // Database delete all methods.
        displayItems();                                                             // display items method.
    }

    private class ItemsCursorAdapter extends CursorAdapter {                        // Items cursor.
        private LayoutInflater layoutInflater;                                      // Private layout variable.

        // Cursor for each item
        public ItemsCursorAdapter(Context context, Cursor cursor, int flags) {      // Items cursor adapter method.
            super(context, cursor, flags);                                          // Super method for flags.
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);// layout inflater variable.
        }

        // Display the item to the view
        @Override
        public void bindView(View view, Context context, Cursor cursor) {           // Bind view method.
            Item item = new Item();                                                 // Item object.
            item.id = cursor.getInt(cursor.getColumnIndex("_id"));               // Cursor int object.
            item.task = cursor.getString(cursor.getColumnIndex("task"));         // Cursor int object.

            RadioButton radioButton = view.findViewById(R.id.radiobutton_task);     // Radio button variables.
            radioButton.setText(item.task);                                         // radio button set text.


            radioButton.setOnClickListener(new View.OnClickListener() {              // on click for listener.
                // Delete the item
                @Override
                public void onClick(View view) {                                    // Onclick method.
                    database.deleteItem(item.id);                                   // Database item delete.
                    displayItems();                                                 // delete method.
                }
            });
        }

        // Set the layout to be used for the display of each item
        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {     // view method.
            return layoutInflater.inflate(R.layout.listview_row_item_radiobutton, parent, false);// return layout.
        }
    }
}