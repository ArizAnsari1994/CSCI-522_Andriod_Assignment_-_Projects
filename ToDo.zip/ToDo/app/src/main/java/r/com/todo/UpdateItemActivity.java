package r.com.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateItemActivity extends AppCompatActivity {                             //Update activity.

    private ItemsDatabase database;                                                     // Private data member for database.
    private Item itemToUpdate;                                                          // Private item for item to update.

    // Initialize the item for updating
    @Override
    protected void onCreate(Bundle savedInstanceState) {                                // On create Instance.
        super.onCreate(savedInstanceState);                                             // Super class on create method.
        setContentView(R.layout.activity_update_item);                                  // Main activity display.

        database = new ItemsDatabase(this);                                     // Date Base item.

        Intent intent = getIntent();                                                    // Get Intent.
        itemToUpdate = (Item) intent.getSerializableExtra("item");               // Item. get serial.
        ((EditText) findViewById(R.id.edittext_task)).setText(itemToUpdate.task);      // Find by id .
    }

    // Update and finish the activity
    public void updateItem(View view) {                                                 // Update Item method.
        EditText editTextTask = findViewById(R.id.edittext_task);                       // find by R.id.
        String task = editTextTask.getText().toString().trim();                         // Get String.

        if(task.isEmpty())                                                              // Task is empty.
            return;                                                                     // Return.

        itemToUpdate.task = task;                                                       // Item update.
        database.updateItem(itemToUpdate);                                              // Database update.

        Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show();   // Make toast.
        finish();                                                                        // Finish.
    }

    // Finish the activity
    public void back(View view) {
        finish();
    }                                                   // Back activity.
}