/************************************************************************
 *                                                                      *
 *  CSCI 322/522               Assignment 9                   Fall 2020 *
 *                                                                      *
 *     Class Name: MainActivity.java                                    *
 *                                                                      *
 *   Developer(s): Ariz Ansari (Z1885929 ) & Mansoor Shireef (Z1874994) *
 *       Due Date: 09 Dec 2020                                          *
 *                                                                      *
 *        Purpose: Using Andriod SQLite.                                *
 ************************************************************************/

package r.com.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {                                       // Main Activity.

    private ItemsDatabase database;                                                         // Private data member for database.

    // Initialize the display of items
    @Override
    protected void onCreate(Bundle savedInstanceState) {                                    // On create Instance.
        super.onCreate(savedInstanceState);                                                 // Super class on create method.
        setContentView(R.layout.activity_main);                                             // Main activity display.

        database = new ItemsDatabase(this);                                         // new Instance of database.
        displayItems();                                                                     // Display Items method call.
    }

    // Show the menu items
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {                                         // On create option menu.
        getMenuInflater().inflate(R.menu.menu_main, menu);                                  // Get Menu flater.
        return true;// return True.
    }

    // Handle the selected menu
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {                                // On select method.
        if(menuItem.getItemId() == R.id.menu_add) {                                          // If R.id is selected.
            Intent intent = new Intent(this, AddItemActivity.class);           // Intent for new Add Item Activity.
            startActivityForResult(intent, 1);                                   // Start activity request.
        } else if(menuItem.getItemId() == R.id.menu_delete) {                               // Else if for r.id is selected.
            Intent intent = new Intent(this, DeleteItemActivity.class);       // Intent for delete item activity.
            startActivityForResult(intent, 2);                                  // Start activity.
        }

        return true;
    }

    // Redisplay the data after doing an add or delete
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {            // On activity result.
        super.onActivityResult(requestCode, resultCode, data);                              // Super on activity result.
        displayItems();                                                                     // Display Items.
    }

    // Display the items on a list view
    private void displayItems() {                                                           // Display Items.
        Cursor cursor = database.retrieveItems();                                           // Retrieve item method from databse.
        ItemsCursorAdapter cursorAdapter = new ItemsCursorAdapter(this, cursor, 0);// New cursor adapter.
        ((ListView)findViewById(R.id.listview_items)).setAdapter(cursorAdapter);            // Find View by id.
    }

    private class ItemsCursorAdapter extends CursorAdapter {                                // class Items Cursor Adapter.
        private LayoutInflater layoutInflater;                                              // class Items Cursor Adapter.

        // Cursor for each item
        public ItemsCursorAdapter(Context context, Cursor cursor, int flags) {              // ItemsCursorAdapter method.
            super(context, cursor, flags);                                                  // Super method.
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);// layout method.
        }

        // Display the item to the view
        @Override
        public void bindView(View view, Context context, Cursor cursor) {                   // BindView Method.
            Item item = new Item();                                                         // Item object.
            item.id = cursor.getInt(cursor.getColumnIndex("_id"));                      // cursor id.
            item.task = cursor.getString(cursor.getColumnIndex("task"));                // task cursor.
            item.completed = Boolean.parseBoolean(cursor.getString(cursor.getColumnIndex("completed")));// item completed variable.

            CheckBox checkBox = view.findViewById(R.id.checkbox_task);                      // R.id for check Box.
            checkBox.setChecked(item.completed);// Check box.

            // Update the database for any changes of state of completion of task
            checkBox.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){     // Listener method.
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean state) {// On clicked changed listiner.
                    item.completed = state;                                                 // Completed is status.
                    database.updateItem(item);                                              // Database update.
                }
            });

            // Show the update activity when the task is pressed
            TextView textView = view.findViewById(R.id.textview_task);                      // R.id for check Box.
            textView.setText(item.task);                                                    // Set Text for checkbox.

            textView.setOnClickListener(new View.OnClickListener() {                        // Listener method.
                @Override
                public void onClick(View view) {                                            // On checked changed method.
                    Intent intent = new Intent(MainActivity.this, UpdateItemActivity.class);// Item complete status.
                    intent.putExtra("item", item);                                   // Database update item.
                    startActivityForResult(intent, 3);                          // Start Activity.
                }
            });
        }

        // Set the layout to be used for the display of each item
        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {             // New view method.
            return layoutInflater.inflate(R.layout.listview_row_item_checkbox, parent, false);// Return Layout.
        }
    }
}