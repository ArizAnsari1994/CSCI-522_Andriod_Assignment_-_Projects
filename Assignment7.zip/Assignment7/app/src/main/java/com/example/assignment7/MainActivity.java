/************************************************************************
 *                                                                      *
 *  CSCI 322/522               Assignment 7                  Fall 2020  *
 *                                                                      *
 *     Class Name: MainActivity.java                                    *
 *                                                                      *
 *   Developer(s): Ariz Ansari (Z1885929 ) & Mansoor Shireef (Z1874994) *
 *       Due Date: 06 Nov 2020                                          *
 *                                                                      *
 *        Purpose: Intents and Activities                               *
 ************************************************************************/

package com.example.assignment7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Spinner spinner;                                        //Spinner object.
    private ImageView imageView;                                    //Image Object.
    private Button button;                                          //Button Object.
    String caseOption;                                              //String Variable.


    @Override
    protected void onCreate(Bundle savedInstanceState) {            //On create class.
        super.onCreate(savedInstanceState);                         //Super class object.
        setContentView(R.layout.activity_main);                     //Main activity.

        spinner = findViewById(R.id.spinner);                       //Find view by Id.
        imageView = findViewById(R.id.imageView);                   //Find view by Id.
        button = findViewById(R.id.button);                         //Find view by Id.

        String [] Cars = {"Mazda Mx-5" , "Mustang" , "Porsche 911" , "Subaru" , "Camaro"}; // String Array variable for spinner class.

        ArrayAdapter<String> adapter =  new ArrayAdapter<String> (this, android.R.layout.simple_spinner_dropdown_item , Cars);//Spinner to Array maping

        spinner.setAdapter(adapter);                                //Spinner set.

       spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { //Spinner listener.
           @Override
           public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {   //Object Overiding.
               switch (position){                                   //Switch Case.
                   case 0 :                                         //Case 0.
                       imageView.setImageResource(R.drawable.mazdamx5);//Setting Object.
                       caseOption = "0";                            //CaseOption to set object.
                       break;
                   case 1 :                                         //Case 1.
                       imageView.setImageResource(R.drawable.mustang);//Setting Object.
                       caseOption = "1";                            //CaseOption to set object.
                       break;
                   case 2 :                                         //Case 2.
                       imageView.setImageResource(R.drawable.porsche);//Setting Object.
                       caseOption = "2";                            //CaseOption to set object.
                       break;
                   case 3:                                          //Case 3.
                       imageView.setImageResource(R.drawable.subarubrz);//Setting Object.
                       caseOption = "3";                            //CaseOption to set object.
                       break;
                   case 4:                                          //Case 4.
                       imageView.setImageResource(R.drawable.camaro);//Setting Object.
                       caseOption = "4";                            //CaseOption to set object.
                       break;

               }
           }

           @Override
           public void onNothingSelected(AdapterView<?> parent) {   //Nothing Select in Spinner.
               imageView.setImageResource(R.drawable.selectcar);    //Set Image.

           }
       });

       button.setOnClickListener(new View.OnClickListener() {       //Button Listener.
           @Override
           public void onClick(View v) {                            //On view.
               opencarSpecifications();                             //Method Call.
           }
       });
    }

    public void opencarSpecifications() {                           //Method Definition.
        Intent intent = new Intent(this, carSpecifications.class);//New Intent.
        intent.putExtra("case_Option", caseOption);          //Sending data from one activity to another.
        startActivity(intent);                                      //Starting Activity.
    }
}