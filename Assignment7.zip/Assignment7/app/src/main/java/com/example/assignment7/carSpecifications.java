package com.example.assignment7;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class carSpecifications extends AppCompatActivity {

    private TextView TextView3;                             //TextView Object.
    private TextView TextView4;                             //TextView Object.
    private Button button1;                                 //Button Object.
    private String caseOption ;                             //String.

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {    //Instance.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_specifications);//Layout display.
        button1 = findViewById(R.id.button2);               //Find View by id.

        Intent intent = getIntent();                        //Getting Intent.


        caseOption = intent.getStringExtra("case_Option");// Getting Data From Previous View.
        TextView3 = findViewById(R.id.textView3);           //Find View by id.
        TextView4 = findViewById(R.id.textView4);           //Find View by id.

        if (caseOption.equals("0")) {                       //If case.
            TextView4.setText("Mazda MX-5" );               //Set TextView.
            TextView3.setText("\tCC : 1998 \n" +            //Set TextView.
                    "\tMax. power: 181 Hp \n" +
                    "\t0-60 MPH: 6.5 sec\n" +
                    "\tMax Speed : 123 mph\n" +
                    "\tEngine Type : 2.0L DOHC 16-valve 4-cylinder with VVT\n\n" +
                    "The Mazda MX-5 (ND) is the fourth and current generation of the Mazda MX-5. Mazda officially unveiled the car on September 3, 2014, in the United States and Spain, and on September 4, 2014, in Japan.The new MX-5 was presented at the October 2014 Paris Motor Show, and at the November 2014 Los Angeles Auto Show. The car is manufactured in Mazda's Hiroshima plant since March 4, 2015. The vehicle was released in the third quarter of 2015. In the US, the release price of the MX-5 was between $24,915 and $30,065. On March 24, 2016 the MX-5 was awarded World Car of the Year (WCOTY) and the World Car Design of the Year at the New York Auto Show. It was the second Mazda to win WCOTY following the Demio/Mazda2 in 2008.\n\n" +                   "\n" +
                    "The fourth generation MX-5 is 105 mm (4 inches) shorter and 100 kg (220 lb) lighter than its predecessor, putting the vehicle's curb weight near 1,000 kg (2,200 lb). Incorporating Mazda's SKYACTIV technology, the Miata is offered with a choice of two direct injection, naturally aspirated petrol engines. The base model has a 1.5 L 96 kW (129 hp; 131 PS) engine, while the 1,998 cc (2.0 L; 121.9 cu in) North American (United States and Canada) ND1 (pre-2019) cars are rated at 116 kW (155 hp; 157 PS) at 6000 rpm and 201 N⋅m (148 lb⋅ft) at 4600 rpm of torque. Mazda also replaced the hydraulic power steering system that the previous Miatas had with their new Electric Power Assisted Steering (EPAS) system.\n\n" +
                    "The car was launched with a six-speed manual shift transmission and a six-speed automatic transmission. The cockpit, steering wheel, and infotainment system are very similar to the 2014 Mazda3. The MX-5 is fitted as standard with a manually operated fabric roof that can be opened or closed within a few seconds." );

            TextView3.setMovementMethod(new ScrollingMovementMethod()); //Scroll on.
        }

        else if (caseOption.equals("1")) {                  //Else if.
            TextView4.setText("Ford Mustang" );            //Set TextView.
            TextView3.setText("\tCC : 5038 \n" +           //Set TextView.
                    "\tMax. power: 480 Hp \n" +
                    "\t0-60 MPH: 4.4 sec\n" +
                    "\tMax Speed : 163 mph\n" +
                    "\tEngine Type : DOHC 32-valve V-8\n\n" +
                    "The Ford Mustang is a series of American automobiles manufactured by Ford. In continuous production since 1964, the Mustang is currently the longest-produced Ford car nameplate. Currently in its sixth generation, it is the fifth-best selling Ford car nameplate. The namesake of the \"pony car\" automobile segment, the Mustang was developed as a highly styled line of sporty coupes and convertibles derived from existing model lines, initially distinguished by \"long hood, short deck\" proportions." +
                    "Originally predicted to sell 100,000 vehicles yearly, the 1965 Mustang became the most successful vehicle launch since the 1927 Model A. Introduced on April 17, 1964 (16 days after the Plymouth Barracuda), over 400,000 units in its first year; the one-millionth Mustang was sold within two years of its launch. In August 2018, Ford produced the 10-millionth Mustang; matching the first 1965 Mustang, the vehicle was a 2019 Wimbledon White convertible with a V8 engine."+
                    "The success of the Mustang launch would lead to multiple competitors from other American manufacturers, including the Chevrolet Camaro and Pontiac Firebird(1967), AMC Javelin (1968), and Dodge Challenger(1970). The Mustang would also have an effect on designs of coupés worldwide, leading to the marketing of the Toyota Celica and Ford Capri in the United States (the latter, by Lincoln-Mercury). The Mercury Cougar was launched in 1967 as a higher-trim version of the Mustang; during the 1970s, it was repackaged as a personal luxury car.");

            TextView3.setMovementMethod(new ScrollingMovementMethod()); //Scroll on.
        }
        else if (caseOption.equals("2")) {                     //Else if.
            TextView4.setText("Porsche 911 Turbo");            //Set TextView.
            TextView3.setText("\tCC : 6000 \n" +               //Set TextView.
                    "\tMax. power: 572 Hp \n" +
                    "\t0-60 MPH: 2.7 sec\n" +
                    "\tMax Speed : 199 mph\n" +
                    "\tEngine Type : Twin-turbocharged boxer 6\n\n" +
                    "Our engineers like to talk about the most perfect sports car ever. Extremely sporty, at the same time comfortable and fully suitable for everyday use. The new 911 Turbo models also consistently follow this path.\n\n" +
                    "The Porsche 911 (pronounced Nine Eleven or in German: Neunelfer) is a two-door, 2+2 high performance rear-engined sports car. Introduced in September 1964 by Porsche AG of Stuttgart, Germany. It has a rear-mounted flat-six engine and all round independent suspension. It has undergone continuous development, though the basic concept has remained unchanged.The engines were air-cooled until the introduction of the Type 996 in 1998, with the 993, produced from 1994–1998 model years, being the last of the air-cooled Porsche sports cars\n\n"+
                    "The 911 has been modified by private teams and by the factory itself for racing, rallying, and other forms of automotive competition. It is among the most successful competition cars. In the mid-1970s, the naturally aspirated 911 Carrera RSR won major world championship sports car races, such as Targa Florio and 24 Hours of Daytona, even against prototypes. The 911-derived 935 turbo also won the 24 Hours of Le Mans in 1979 and Porsche won World Championship for Makes titles in 1976, 1977, 1978 and 1979 with 911-derived models.");

            TextView3.setMovementMethod(new ScrollingMovementMethod()); //Scroll on.
        }


        else if (caseOption.equals("3")) {                    //Else if.
            TextView4.setText("Subaru BRZ");                 //Set TextView.
            TextView3.setText("\tCC : 2500 \n" +            //Set TextView.
                    "\tMax. power: 205 Hp \n" +
                    "\t0-60 MPH: 6.7 sec\n" +
                    "\tMax Speed : 143 mph\n" +
                    "\tEngine Type : 2.0L 4cyl 6M\n\n\n" +
                    "The Toyota 86 is a 2+2 sports car jointly developed by Toyota and Subaru, manufactured at Subaru's Gunma assembly plant along with a badge engineered variant, marketed as the Subaru BRZ.\n" +
                    "\n" +
                    "The 2+2 fastback coupé is noted for its naturally-aspirated boxer engine, front-engined, rear-wheel-drive configuration, 53/47 front/rear weight balance and low center of gravity — and for drawing inspiration from Toyota's earlier AE86, a small, light, front-engine/rear-drive Corolla variant widely popular for Showroom Stock, Group A, and Group N, Rally, Club and drift racing.\n" +
                    "\n" +
                    "Toyota markets the sports car as the 86 in Asia, Australia, North America (from August 2016), South Africa, and South America; as the Toyota GT86 in Europe; as the 86 and GT86 in New Zealand; as the Toyota FT86 in Nicaragua and Jamaica and as the Scion FR-S (2012-2016) in the United States and Canada.");

            TextView3.setMovementMethod(new ScrollingMovementMethod()); //Scroll on.
        }

        else if (caseOption.equals("4")) {                   //Else if.
            TextView4.setText("Camaro");                    //Set TextView.
            TextView3.setText("\tCC : 4200 \n" +            //Set TextView.
                    "\tMax. power: 455  Hp \n" +
                    "\t0-60 MPH: 3.9 sec\n" +
                    "\tMax Speed : 150 mph\n" +
                    "\tEngine Type : 6.2L V-8 Engine\n\n\n" +
                   "The Chevrolet Camaro is a mid-size American automobile manufactured by Chevrolet, classified as a pony car and some versions also as a muscle car. It went on sale on September 29, 1966, for the 1967 model year and was designed as a competing model to the Ford Mustang. The car shared its platform and major components with the Pontiac Firebird, also introduced for 1967.\n" +
                    "\n" +
                    "Four distinct generations of the Camaro were developed before production ended in 2002. The nameplate was revived on a concept car that evolved into the fifth-generation Camaro; production started on March 16, 2009. Over 5 million Camaros have been sold.\n" +
                    "\n" +
                    "According to the book The Complete Book of Camaro: Every Model Since 1967, the name Camaro was conceived by Chevrolet merchandising manager Bob Lund and General Motors vice president Ed Rollett, while they were reading the book Heath's French and English Dictionary by James Boïelle and by de V. Payen-Payne printed in 1936. In the book The Complete Book of Camaro, it states that Mr. Lund and Mr. Rollett found the word camaro in the French-English dictionary was slang, to mean friend, pal, or comrade. The article further repeated Estes's statement of what the word camaro was meant to imply, that the car's name \"suggests the comradeship of good friends, as a personal car should be to its owner\". In fact, the actual French word that has that meaning is \"camarade,\" from which the English word \"comrade\" is derived, and not \"camaro\"; \"camaro\" is not a recognized word in the French language.");

            TextView3.setMovementMethod(new ScrollingMovementMethod()); //Scroll on.
        }

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActitivy();         //Method Call
            }
        });      //Button Listner.
    }

    public void openMainActitivy(){                         //Method Defination.
        Intent intent = new Intent(this, MainActivity.class);//Activity call.
        startActivity(intent);                              //Activity Start.
    }
}