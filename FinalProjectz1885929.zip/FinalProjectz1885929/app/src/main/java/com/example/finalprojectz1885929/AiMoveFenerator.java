package com.example.finalprojectz1885929;

import java.util.Random;

public class AiMoveFenerator {                                                      //Ai Move generator class.
    private Board board ;                                                           //Board variable.

    public AiMoveFenerator(Board board) {                                           //Ai Move generator constructor.
        this.board = board;                                                         //board variable.
    }

    public Integer getMove(){                                                       //GetMove method.
        if(board.isFull()) {                                                        //if condition check for board is full.
            return null ;                                                           //Return Null.
        }
        while(true){                                                                //While True.
            int iaMove = new Random().nextInt(9);                            //Iamove for random number from 0 to 8.
            if(board.isEmpty( iaMove)){                                             //if condition for board id full or not.
                return iaMove ;                                                     //Return board.
            }
        }
    }
}
