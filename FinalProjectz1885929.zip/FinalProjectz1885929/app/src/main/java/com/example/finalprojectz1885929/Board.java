package com.example.finalprojectz1885929;

import android.media.Image;

import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

public class Board {                                                                    //Class Board.

    private List<String> marks = new ArrayList<>(asList("" , "" , "" ,"" , "" , "" , "" , "" , "" ));//Emplty list.
    private List <PossibleWin> possiblewins = new ArrayList<>();                        //Array List.

    public Board(){                                                                         //Board Constructor.
        possiblewins.add(new PossibleWin(0,1,2));                         //Add Possible Winds
        possiblewins.add(new PossibleWin(3,4,5));                         //Add Possible Winds
        possiblewins.add(new PossibleWin(6,7,8));                         //Add Possible Winds

        possiblewins.add(new PossibleWin(0,3,6));                         //Add Possible Winds
        possiblewins.add(new PossibleWin(1,4,7));                         //Add Possible Winds
        possiblewins.add(new PossibleWin(2,5,8));                         //Add Possible Winds

        possiblewins.add(new PossibleWin(0,4,8));                         //Add Possible Winds
        possiblewins.add(new PossibleWin(2,4,6));                         //Add Possible Winds
    }

    public void mark(Integer position , String symbol){
        marks.set(position,symbol);
    }                                 //Mark method set function.


   public boolean hasWon (Player player){                                                   //Boolean hasWon method.
       for (PossibleWin possiblewin : possiblewins) {                                       //Iteratera possiblewins.
           if (checkIfAreTheSame(possiblewin , player.getSymbol())) {                       //If condition check,
               return true;                                                                 //Return True.
           }
       }
       return false;                                                                        //Return false.
   }

   public void erase (){
        marks = new ArrayList<>(asList("" , "" , "","" , "" , "","" , "" , ""));
   }//Erase method.

   private boolean checkIfAreTheSame (PossibleWin possibleWin , String playerSymbol){       //Checkifsame method.
        return marks.get(possibleWin.getFirst()).equals(playerSymbol) &&                    //Return the locations.
                marks.get(possibleWin.getSecond()).equals(playerSymbol) &&
                marks.get(possibleWin.getThird()).equals(playerSymbol);
   }

    public boolean isFull() {                                                               //Isfull method.
        for (String mark : marks)                                                           //Iteratable of marks.
        {
            if(mark.isEmpty()) {                                                            //Mark if empty
                return false;                                                               //Return false.
            }
        }
        return true;                                                                        //Return true.
    }

    public boolean isEmpty(int iaMove){                                                     //Isemplty method.
        return marks.get(iaMove).isEmpty();                                                 //Return marks.
    }
}
