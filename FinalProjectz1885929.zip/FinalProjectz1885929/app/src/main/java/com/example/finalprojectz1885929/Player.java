package com.example.finalprojectz1885929;

public class Player {                                                                   //Player Class.

    private String symbol ;                                                             //String Symbol.
    private String winnigText;                                                          //String winningtext.
    public Player(String symbol, String winnigText) {                                   //player constructor.
        this.symbol = symbol;                                                           //setting variable.
        this.winnigText = winnigText;                                                   //setting variable.
    }

    public String getWinnigText() {
        return winnigText;
    }                                                 //Getter method.

    public String getSymbol() {
        return symbol;
    }                                                     //Getter method.
}
