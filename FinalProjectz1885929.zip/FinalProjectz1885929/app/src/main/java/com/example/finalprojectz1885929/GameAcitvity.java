package com.example.finalprojectz1885929;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class GameAcitvity extends AppCompatActivity {                                   //Game Activity.

    public static final String PLAYER_SYMBOL = "X";                                     //String for player Symbol.
    public static final String AI_SYMBOL = "O" ;                                        //String for AI symbol.
    private TextView gameResultTv;                                                      //Textview gameresult.
    private List<Button> buttons ;                                                      //Button List.
    private Button startButton;                                                         //Start Button.
    private Board board;                                                                //Board variable.
    private Player player = new Player(PLAYER_SYMBOL, "You Win!! You can drive your car. Safe Journey!!!!");//Player class method.
    private Player aiPlayer = new Player(AI_SYMBOL, "You Lose!! Your car is disabled & take a cab!!!!");//Aiplayer class method.
    private AiMoveFenerator aiMoveFenerator;                                            //AiMoveFenerator for class.
    private boolean gameOver = false ;                                                  //Boolean for gameover false.

    @Override
    protected void onCreate(Bundle savedInstanceState) {                                //On create.
        super.onCreate(savedInstanceState);                                             //Super on create.
        setContentView(R.layout.activity_game_acitvity);                                //Get layout content.
        initializeUi();                                                                 //Initialize Ui Method call.
        board = new Board();                                                            //New board initialization.
        aiMoveFenerator = new AiMoveFenerator(board);                                   //AiMove Generator class instance.
    }

    private void initializeUi() {                                                       //InitializeUI method.
        gameResultTv = findViewById(R.id.tv_gameResult);                                //R.id for tv_gameresult to name gameresultTv.
        initializeStarButton();                                                         //Initialize Star Button.
        initializeButtons();                                                            //Initialize button method call.
    }

    private void initializeStarButton() {                                               //Initialize Star Button defination.
        startButton = findViewById(R.id.b_start);                                       //R.id for B_start to startButton.
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {                                          //StartButton on click listener.
                clearButton();                                                          //Clear Button method call.
                board.erase();                                                          //Erase method call from board.
                gameOver = false ;                                                      //Game Over boolean changed to false.
                gameResultTv.setText("");                                               //Set Text.
                enableButtons();                                                        //Enable Button method.
            }
        });
    }

    private void initializeButtons() {                                                  //Initialize Button method.
        buttons = new ArrayList<>();                                                    //Array List of button.
        buttons.add((Button) findViewById(R.id.b_top_left));                            //Add R.id for b_top_left to array button list.
        buttons.add((Button) findViewById(R.id.b_top_center));                          //Add R.id for b_top_Center to array button list.
        buttons.add((Button) findViewById(R.id.b_top_right));                           //Add R.id for b_top_right to array button list.

        buttons.add((Button) findViewById(R.id.b_middle_left));                         //Add R.id for b_middle_left to array button list.
        buttons.add((Button) findViewById(R.id.b_middle_center));                       //Add R.id for b_middle_Center to array button list.
        buttons.add((Button) findViewById(R.id.b_middle_right));                        //Add R.id for b_middle_right to array button list.

        buttons.add((Button) findViewById(R.id.b_bottom_left));                         //Add R.id for b_bottom_left to array button list.
        buttons.add((Button) findViewById(R.id.b_bottom_center));                       //Add R.id for b_bottom_Center to array button list.
        buttons.add((Button) findViewById(R.id.b_bottom_right));                        //Add R.id for b_bottom_right to array button list.

        addButtonActions();
    }

    private void addButtonActions() {                                                   //Add Button Actions
        for (final Button button : buttons) {                                           //Iterate Button loop.
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {                                           //Onclick Listener.
                    Button clickedButton = (Button) v;                                  //ClickedButton variable.
                    movePlayer(buttons.indexOf(clickedButton));                         //Moveplayer method.
                    if(!gameOver){                                                      //If condition for game over.
                        moveAi();                                                       //MoveAi method call.
                    }
                }
            });
        }
    }

    private void moveAi() {                                                             //MoveAi method.
        Integer aiMove = aiMoveFenerator.getMove();                                     //AimoveGenerator getMove call.
        if(aiMove != null){                                                             //If Condition for checking Aimove == Null.
            markButton(buttons.get(aiMove) , aiPlayer);                                 //MarkButton method call.
            markBoard(aiMove , aiPlayer);                                               //Markboar method call.
            checkWin(aiPlayer);                                                         //checkwin method with aiplayer.
            checkTie();                                                                 //Check tie call.
        }
    }

    private void movePlayer(int playerMove) {                                           //Moveplayer method with player move variable.
        markButton(buttons.get(playerMove),player);                                     //MarkButton method call.
        markBoard(playerMove , player);                                                 //Mark Board method.
        checkWin(player) ;                                                              //Checkwin method with player parameters.
        checkTie();                                                                     //CheckTie method call.
    }


    private void checkTie() {                                                           //Check tie.
        if (!gameOver && board.isFull()) {                                              //If condition for game not over and board if full.
            gameOver = true ;                                                           //Game over is true.
            gameResultTv.setText("Its A Tie. Click start on play Again");               //Set Text.

        }
    }

    private void checkWin(Player player) {                                              //Check Win method.

        if (board.hasWon(player)){                                                      //If condition for board has won.
            gameOver = true ;                                                           //Game over is true.
            gameResultTv.setText(player.getWinnigText());                               //set text for who's winning.
            Toast.makeText(GameAcitvity.this ,player.getWinnigText(), Toast.LENGTH_LONG).show();//Toast message.
            disableButtons();                                                           //Disable Buttons method.
        }

    }

    private void markBoard(int postion , Player player) {                               //Mark Board method.
        board.mark(postion , player.getSymbol());                                       //Calling board mark.
    }

    private void markButton(Button clickedButton , Player player){                      //Mark Button method.
        clickedButton.setText(player.getSymbol());                                      //Set text.
        clickedButton.setClickable(false);                                              //Set click button false.
    }

    private void disableButtons() {                                                     //Disable button method.
        for (Button button : buttons) {                                                 //Button itteratable.
            button.setClickable(false);                                                 //Button clickable to false.
        }
    }

    private void enableButtons() {                                                      //Enable Button method.
        for (Button button : buttons) {                                                 //Button itteratable.
            button.setClickable(true);                                                  //Button clickable to true.
        }
    }

    private void clearButton() {                                                        //Clean Button method.
        for (Button button : buttons) {                                                 //Button itteratable.
            button.setText("");                                                         //Set Text.
        }
    }

}