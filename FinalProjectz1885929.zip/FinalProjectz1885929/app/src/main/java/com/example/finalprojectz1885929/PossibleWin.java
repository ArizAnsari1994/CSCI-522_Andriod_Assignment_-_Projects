package com.example.finalprojectz1885929;

public class PossibleWin {                                                              //Possible Win class.

    private int first;                                                                  //variable First.
    private int second;                                                                 //variable second.
    private int third;                                                                  //variable third.


    public PossibleWin(int first, int second, int third) {                              //Possible win constructor.
        this.first = first;                                                             //variable First.
        this.second = second;                                                           //variable second.
        this.third = third;                                                             //variable third.
    }

    public int getFirst() {
        return first;
    }                                                         //Getter for first.

    public int getSecond() {
        return second;
    }                                                        //Getter for second.

    public int getThird() {
        return third;
    }                                                         //Getter for third.
}
