/************************************************************************
 *                                                                      *
 *  CSCI 322/522            Graduate Project                 Fall 2020  *
 *                                                                      *
 *     Class Name: MainActivity.java                                    *
 *                                                                      *
 *   Developer(s): Ariz Ansari (Z1885929 )                              *
 *       Due Date: 04 Dec 2020                                          *
 *                                                                      *
 *        Purpose: An application which can help find if the car driver *
 *        is in senses.When the driver unlocks his car,with the help his*
 *        GPS location, the app will check if there are any restaurants *
 *        which serves alcohol within 500 ft of the location of the car.*
 *        The vehicle app will direct him to the app to check if the    *
 *        driver is in his senses.  In this place the driver needs to   *
 *        play a simple games of tic tac toe to prove he is not drunk.  *
 *       If the driver wins , the popup will say “You are not drunk,    *
 *       You can driver your car”. Otherwise it should give a popup and *
 *       say “You are drunk, your vehicle has been disabled for the     *
 *       next 1 hour. Please take a cab”.                               *
 ************************************************************************/
package com.example.finalprojectz1885929;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.FloatProperty;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {                                   //Main Activity.

    private EditText Name;                                                              //EditText variable for name.
    private EditText Password;                                                          //EditText variable for password.
    private Button Login;                                                               //Button for Login.
    FusedLocationProviderClient fusedLocationProviderClient;                            //Current Location variable.

    @Override
    protected void onCreate(Bundle savedInstanceState) {                                //On Create Instance.
        super.onCreate(savedInstanceState);                                             //Super on create.
        setContentView(R.layout.activity_main);                                         //Get layout content.

        Name = (EditText) findViewById(R.id.etName);                                    //R.id for name to name variable.
        Password = (EditText) findViewById(R.id.etPassword);                            //R.id for etpassword to name password.
        Login = (Button)findViewById(R.id.btnLogin);                                    //R.id for btnLogin to name login.

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this );  //Getting live location.

        Login.setOnClickListener(new View.OnClickListener() {                           //Login Btn on on click Listener.
            @Override
            public void onClick(View view) {                                            //On click method.
                validate(Name.getText().toString() , Password.getText().toString());    //Calling validate method with name & string variable.
            }
        });
    }

    private void validate ( String userName ,  String userPassword) {                   //Validate Method with two variable.
        if ( (userName.equals("Admin") && (userPassword.equals("Admin"))) ) {                     //equals Id and password.
            getLocation();                                                                  //Get Location method call.
            Toast.makeText(MainActivity.this, "Pl play a game to prove you are not drunk.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, GameAcitvity.class);// Intent method call for intents.
            startActivity(intent);                                                      //start Activity.
        }
        else {
            Toast.makeText(MainActivity.this , "Wrong ID or Password. ", Toast.LENGTH_LONG).show();

        }

    }

    @SuppressLint("MissingPermission")
    private void getLocation() {                                                        //Get Location method.
        fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {                      //Live Location.
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(MainActivity.this , Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ) {
                    Location location = task.getResult();
                                                             //Getting the live location.
                        if (location != null ) {                                                  //If Location is null.
                            try {                                                                   //Try
                                Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault()); //Generating the proper format.
                                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);//Getting latitude and longitude.
                                Toast.makeText(MainActivity.this, "You Longitude is " + addresses.get(0).getLongitude() + " & Latitude is " + addresses.get(0).getLatitude() + " which has a Pub in 100 feet of your Location. Pl play a game to prove you are not drunk.", Toast.LENGTH_LONG).show();
                                //Toast a message with the latitude and longitude.
                                TimeUnit.SECONDS.sleep(0);                              //Sleep for 2 seconds.
                            } catch (IOException | InterruptedException e) {                    //Catch Exceptions.
                                e.printStackTrace();                                            //Prints the exceptions.
                            }
                        }
                }

            }
        });
    }
}