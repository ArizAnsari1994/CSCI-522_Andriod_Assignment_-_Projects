/************************************************************************
 *                                                                      *
 *  CSCI 322/522               Assignment 6                  Fall 2020  *
 *                                                                      *
 *     Class Name: MainActivity.java                                    *
 *                                                                      *
 *   Developer(s): Mohammed Mansoor Shareef  (Z1874994)                 *
 *                 Ariz Ansari ( Z1995929)                              *
 *       Due Date: 16 September 2020                                    *
 *                                                                      *
 *        Purpose:  An Android application that function as a Quadratic *
 *                  equation calculator.When the equation is solved, it *
 *                  can have up to two values for x.These are the places*
 *                  where the x-axis will be intersected if the equation*
 *                  is graphed. If the discriminant is positive, there  *
 *                  are two values for x.                               *
 ************************************************************************/
package com.example.quadraticcalculator;

// Importing the nesscary packages required
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // Two buttons named the calculate and reset are declared
    private Button calbutton, resbutton;
    // The the values of A,B,C are declared as edittext
    private EditText A, B, C;
    // The positive and negative roots of the equations are declared as the textview
    private TextView pos, neg;
    // It save the state of the application in a bundle and it can is passed back to onCreate if the activity needs to be recreated
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //To inform the activity about our choice of UI to be populated  on the activity’s window using setContentView
        setContentView(R.layout.activity_main);
        // findViewById finds the calculate by id  and saves it in calbutton
        calbutton = findViewById(R.id.calculate);
        // findViewById finds the reset by id  and saves it in resetbutton
        resbutton = findViewById(R.id.reset);
        // The setOnClickListner id called when the calbutton is clicked using the this operator
        calbutton.setOnClickListener(this);
        // The setOnClickListner id called when the resetbutton is clicked using the this operator
        resbutton.setOnClickListener(this);
        // FindViewById is called to find all the values required to perform the calculation
        A = findViewById(R.id.a_value);
        B = findViewById(R.id.b_value);
        C = findViewById(R.id.c_value);
        pos = findViewById(R.id.pos_val);
        neg = findViewById(R.id.neg_val);
    }

    // The discriminant value is calculated using the formula b²-4ac
    private double discriminant(double a, double b, double c) {
        double disc;
        disc = Math.pow(b, 2) - (4 * a * c);
        return disc;
    }

    // The onclick Listner interface onClick is called when the view component is clicked
    @Override
    public void onClick(View v) {
        // If the calbutton is clicked then it check all the following conditions if a is 0 and so on
        if(v==calbutton){
            if (!A.getText().toString().isEmpty() && !B.getText().toString().isEmpty() && !C.getText().toString().isEmpty() &&
                    !A.getText().toString().equals(".") && !B.getText().toString().equals(".") && !C.getText().toString().equals(".") &&
                    !A.getText().toString().equals("-") && !B.getText().toString().equals("-") && !C.getText().toString().equals("-")){
                double a = Double.parseDouble(A.getText().toString());
                double b = Double.parseDouble(B.getText().toString());
                double c = Double.parseDouble(C.getText().toString());
                // If the Vlaue of a is zero it asks to correctly enter the value of a as it cannot be 0
                if(a==0){
                    Toast.makeText(this,"Value of A can't be zero", Toast.LENGTH_LONG).show();
                }
                // Else it calculates the discrimninat value using the values of a,b,c
                else{

                    double D = discriminant(a, b, c);
                    // The format of the discriminat is also defined as follows
                    DecimalFormat df = new DecimalFormat("#.0000");

                    // If the value of discriminat is greater than zero then it finds the two roots of the equations
                    if(D >=0){
                        // Calculating the two roots of the equation
                        double sol1 = (-b + Math.sqrt(discriminant(a, b, c))) / (2 * a);
                        double sol2 = (-b - Math.sqrt(discriminant(a, b, c))) / (2 * a);
                        // The roots that are obtained are set as neg and positive respectively
                        pos.setText(df.format(sol1));
                        neg.setText(df.format(sol2));
                    }
                    // If the value of D is less than 0 than  the roots are said to be imaginary the value of pos and neg root is set as imaginary
                    else{
                        String Imaginary = "Roots are imaginary";
                        pos.setText(Imaginary);
                        neg.setText(Imaginary);
                    }
                }
            }
            // If any of the values is not filled it asks to fill in all the values to calculate the roots
            else{
                Toast.makeText(this,"Please Fill all the Three Values", Toast.LENGTH_LONG).show();
            }
        }
        // If the resetbutton is clicked it resets all the values
        else if(v==resbutton){
            A.setText("");
            B.setText("");
            C.setText("");
            pos.setText("Positive Value will be displayed here.");
            neg.setText("Negative Value will be displayed here.");
        }
    }
}